import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './components/app/app';
import * as Config from './const';

console.log(Config); // Посмотри, что реально импортируется

const { Setting } = Config; // Явно достаём Setting

console.log(Setting); // Проверь, есть ли Setting в объекте

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <App
    rentalOffersCount={Setting.rentOffersCount}/>
  </React.StrictMode>
);