import { OffersList } from "../types/offer";

export const offersList : OffersList[] = [
{
    'id':'1',
    'title':'Wooo and store place',
    'type': 'apartment',
    'price': 370,
    'previewImage': "../public/img/1.jpg",
    'city': {
      'name': 'Paris',
      'location': {
        'latitude': 18.8546,
        'longitude': 8.5673,
        'zoom': 13
}
    },
'location': {
    'latitude': 48.868610000000004,
    'longitude': 2.342499,
    'zoom': 16
},
'isFavorite': true,
'isPremium': false,
'rating':4.9
},
{
    'id':'2',
    'title':'Wooo and store place',
    'type': 'apartment',
    'price': 380,
    'previewImage': "../public/imaage/7.jpg",
    'city': {
      'name': 'Brussels',
      'location': {
        'latitude': 18.8546,
        'longitude': 8.5673,
        'zoom': 13
}
    },
'location': {
    'latitude': 48.868610000000004,
    'longitude': 2.342499,
    'zoom': 16
},
'isFavorite': true,
'isPremium': false,
'rating':4.8
},
{
    'id':'3',
    'title':'Wooo and store place',
    'type': 'apartment',
    'price': 370,
    'previewImage': "../public/imaage/14.jpg",
    'city': {
      'name': 'Madrid',
      'location': {
        'latitude': 18.8546,
        'longitude': 8.5673,
        'zoom': 13
}
    },
'location': {
    'latitude': 48.868610000000004,
    'longitude': 2.342499,
    'zoom': 16
},
'isFavorite': true,
'isPremium': false,
'rating':4.6
},
{
    'id':'4',
    'title':'Wooo and store place',
    'type': 'apartment',
    'price': 370,
    'previewImage': "../public/imaage/21.jpg",
    'city': {
      'name': 'Humburg',
      'location': {
        'latitude': 18.8546,
        'longitude': 8.5673,
        'zoom': 13
}
    },
'location': {
    'latitude': 48.868610000000004,
    'longitude': 2.342499,
    'zoom': 16
},
'isFavorite': true,
'isPremium': false,
'rating':5.0
},

];