import { FullOffer } from "../types/offer";

const offers: FullOffer[] = [
   { 
    'id': 'bbb06abe-3f92-446d-9a68-cb64b5d38e2b' ,
    'title': 'Wood and stone place',
    'description': 'A new spacious villa, one floor. All commodities, jacuzzi and beautiful scenery. Ideal for families',
    'type': 'apartment',
    'price': 370,
    'images': [
    '7. jpg',
    '8. jpg',
    '9. jpg',
    '10. jpg',
    '11. jpg',
    '12.jpg'
    ],
    'city': {
        'name': 'Paris',
        'location': {
        'latitude': 48.85661,
        'longitude': 2.351499,
        'zoom': 13
        }
        },
        'location': {
        'latitude': 48.868610000000004,
        'longitude': 2.342499,
        'zoom': 16
        },
'goods': [
'Heating',
'Wi-Fi',
'Fridge',
'Laptop friendly workspace',
'Baby seat',
'Air conditioning',
'Washer',
'Towels',
'Dishwasher',
'Kitchen',
'Washing machine',
'Breakfast',
'Coffee machine'
],
'host': {
'isPro': true,
'name': 'Angelina',
'avatarUrl': 'avatar-angelina.jpg'
},
'isPremium': false,
'isFavorite': true,
'rating': 4.9,
'bedrooms': 2,
'maxAdults': 3
},
    {
      id: 'offer-amsterdam-001',
      title: 'Wood and stone place',
      description:
        'A new spacious villa, one floor. All commodities, jacuzzi and beautiful scenery. Ideal for families',
      type: 'apartment',
      price: 370,
      images: ['1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg', '6.jpg'],
      city: {
        name: 'Amsterdam',
        location: {
          latitude: 52.3676,
          longitude: 4.9041,
          zoom: 13,
        },
      },
      location: {
        latitude: 52.3700,
        longitude: 4.8950,
        zoom: 16,
      },
      goods: [
        'Heating',
        'Wi-Fi',
        'Fridge',
        'Laptop friendly workspace',
        'Baby seat',
        'Air conditioning',
        'Washer',
        'Towels',
        'Dishwasher',
        'Kitchen',
        'Washing machine',
        'Breakfast',
        'Coffee machine',
      ],
      host: {
        isPro: true,
        name: 'Angelina',
        avatarUrl: 'avatar-angelina.jpg',
      },
      isPremium: false,
      isFavorite: true,
      rating: 4.9,
      bedrooms: 2,
      maxAdults: 3,
    },
    {
      id: 'offer-hamburg-001',
      title: 'Wood and stone place',
      description:
        'A new spacious villa, one floor. All commodities, jacuzzi and beautiful scenery. Ideal for families',
      type: 'apartment',
      price: 370,
      images: ['13.jpg', '14.jpg', '15.jpg', '16.jpg', '17.jpg', '18.jpg'],
      city: {
        name: 'Hamburg',
        location: {
          latitude: 53.5511,
          longitude: 9.9937,
          zoom: 13,
        },
      },
      location: {
        latitude: 53.5540,
        longitude: 9.9900,
        zoom: 16,
      },
      goods: [
        'Heating',
        'Wi-Fi',
        'Fridge',
        'Laptop friendly workspace',
        'Baby seat',
        'Air conditioning',
        'Washer',
        'Towels',
        'Dishwasher',
        'Kitchen',
        'Washing machine',
        'Breakfast',
        'Coffee machine',
      ],
      host: {
        isPro: true,
        name: 'Angelina',
        avatarUrl: 'avatar-angelina.jpg',
      },
      isPremium: false,
      isFavorite: true,
      rating: 4.9,
      bedrooms: 2,
      maxAdults: 3,
    },
    {
      id: 'offer-brussels-001',
      title: 'Wood and stone place',
      description:
        'A new spacious villa, one floor. All commodities, jacuzzi and beautiful scenery. Ideal for families',
      type: 'apartment',
      price: 370,
      images: ['19.jpg', '20.jpg', '21.jpg', '22.jpg', '23.jpg', '24.jpg'],
      city: {
        name: 'Brussels',
        location: {
          latitude: 50.8503,
          longitude: 4.3517,
          zoom: 13,
        },
      },
      location: {
        latitude: 50.8540,
        longitude: 4.3500,
        zoom: 16,
      },
      goods: [
        'Heating',
        'Wi-Fi',
        'Fridge',
        'Laptop friendly workspace',
        'Baby seat',
        'Air conditioning',
        'Washer',
        'Towels',
        'Dishwasher',
        'Kitchen',
        'Washing machine',
        'Breakfast',
        'Coffee machine',
      ],
      host: {
        isPro: true,
        name: 'Angelina',
        avatarUrl: 'avatar-angelina.jpg',
      },
      isPremium: false,
      isFavorite: true,
      rating: 4.9,
      bedrooms: 2,
      maxAdults: 3,
    },
  

]

export {offers};
