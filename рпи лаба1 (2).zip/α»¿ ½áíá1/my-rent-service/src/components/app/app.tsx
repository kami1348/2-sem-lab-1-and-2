import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import MainPage from "../../pages/main-page/main-page";
import Favorites from "../../pages/favorites";
import Login from "../../pages/login";
import Offer from "../../pages/offer";
import NotFound from "../../pages/error";
import { JSX } from "react";
import { AppRoute } from "../../const";
import {AutorizationStatus} from "../../const";
import { PrivateRoute } from "../private-route/private-route";
import { FullOffer } from "../../types/offer";

type AppMainPageProps = {
  rentalOffersCount: number;
  offers: FullOffer[];
};

function App({ rentalOffersCount, offers }: AppMainPageProps): JSX.Element {
  return (
    <Router>
      <Routes>
        <Route
          path={AppRoute.Main}
          element={<MainPage rentalOffersCount={rentalOffersCount} />}
        />
        <Route path={AppRoute.Favorites} element={<PrivateRoute autorizationStatus={AutorizationStatus.NoAuth} > <Favorites/> </PrivateRoute>} />
        <Route path={AppRoute.Login} element={<Login />} />
        <Route path={AppRoute.Offer} element={<Offer />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;