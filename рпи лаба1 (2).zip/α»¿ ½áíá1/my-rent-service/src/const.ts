export const Setting = {
    rentOffersCount: 312,
} as const;